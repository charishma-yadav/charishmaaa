public interface Notification {
    void notifyUser();
}